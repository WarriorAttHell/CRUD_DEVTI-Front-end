let id, idForm, nomForm, depForm, salForm;
const sURL = 'http://localhost:8081/api/funcionario/';

window.onload = async function (e) {
    const query = window.location.search;
    const parametros = new URLSearchParams(query);
    id = parametros.get('id');

    idForm = document.querySelector('#iID');
    nomForm = document.querySelector('#iNome');
    depForm = document.querySelector('#iDependentes');
    salForm = document.querySelector('#iSalario');

    const fun = await buscarFuncionario(id);
    preencherForm(fun);
};

function preencherForm(fun) {
    idForm.value = fun.id;
    nomForm.value = fun.nome;
    depForm.value = fun.dependentes;
    salForm.value = fun.salario;
}

async function buscarFuncionario(id) {
    const resposta = await axios.get(sURL + id);

    return resposta.data;
}

async function alterarFuncionario() {
    const id = idForm.value;
    const nome = nomForm.value; 
    const dependentes = depForm.value;
    const salario = salForm.value;

    axios.put(sURL, { id, nome, dependentes, salario })
        .then(res => {
            alert(JSON.stringify(res.data));
            console.log(res.data);
            setTimeout(() => window.location.href = '/', 100);
        })
        .catch(res => console.log(res.response.data));
}