let idForm, nomForm, depForm, salForm;
const sURL = 'http://localhost:8081/api/funcionario/';

window.onload = function (e) {
    idForm = document.querySelector('#iID');
    nomForm = document.querySelector('#iNome');
    depForm = document.querySelector('#iDependentes');
    salForm = document.querySelector('#iSalario');
};

async function incluirFuncionario() {
    const id = idForm.value;
    const nome = nomForm.value; 
    const dependentes = depForm.value;
    const salario = salForm.value;

    axios.post(sURL, { id, nome, dependentes ,salario })
        .then(res => {
            res.data.toString = function() {
                return 'ID: ' + this.id + '\nNome: ' + this.nome +
                    '\nDependentes: ' + this.dependentes + '\nSalario: ' + this.salario;
                }

            alert(res.data.toString());
            console.log(res.data);
            setTimeout(() => window.location.href = '/', 100);
        })
        .catch(res => console.log(res.response.data));
}